﻿//davaleba 1



//Console.WriteLine("Enter a number: ");
//int length = Convert.ToInt32(Console.ReadLine());

//int[] array = new int[length];

//for (int i = 0; i < length; i++)
//{
//    array[i] = i;
//}

//Console.WriteLine("Arrays elementebi:");

//foreach (int element in array)
//{
//    Console.WriteLine(element);
//}





//davaleba 2



//int[] array = new int[10] { 2, 15, 20, 8, 3, 36, 42, 5, 1, 28 };
//int sum = 0;

//foreach (int num in array)
//{
//    sum += num;

//}

//int max = 0;

//for (int i = 0; i < array.Length; i++)
//{
//    if (array[i] > max)
//    {
//        max = array[i];
//    }
//}

//Console.WriteLine(max);

//Console.WriteLine("Sum of the numbers: " + sum);


////davaleba 3

//int[] array = new int[10] { 17, 19, 3, 8, 26, 18, 44, 15, 22, 56, };

//int oddCount = 0;
//int evenCount = 0;



